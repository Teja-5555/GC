import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

const SYSTEM_PROMPT = `You are an Excel expert. Help users with Excel formulas, 
functions, and best practices. Be concise but thorough in your explanations.
Always include practical examples.`;

export const send = mutation({
  args: { content: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Store user's message
    await ctx.db.insert("messages", {
      userId,
      content: args.content,
      role: "user",
    });

    // Get chat history
    const messages = await ctx.db
      .query("messages")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    // Get AI response
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...messages.map(msg => ({
          role: msg.role as "user" | "assistant",
          content: msg.content
        }))
      ],
    });

    const aiMessage = response.choices[0].message.content;

    // Store AI's response
    await ctx.db.insert("messages", {
      userId,
      content: aiMessage ?? "Sorry, I couldn't generate a response",
      role: "assistant",
    });

    return aiMessage;
  },
});

export const list = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("messages")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});
